# Sistema de Nómina - Programación Orientada a Objetos

## Integrantes
- Marcelo Licona López  
- Dania Correa Espitia  
- María José Isaza  
- Dianis Palomo  

## Descripción
Sistema de nómina en Java usando POO.
