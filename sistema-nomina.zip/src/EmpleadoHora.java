public class EmpleadoHora extends empleados {
    private int horas;

    public EmpleadoHora(String nombre, double salario, int horas) {
        super(nombre, salario);
        this.horas = horas;
    }

    public double calcularSalariobruto() {
        return horas * salariobase;
    }
}
