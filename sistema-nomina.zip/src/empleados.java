public abstract class empleados {
    protected String nombre;
    protected double salariobase;

    public empleados(String nombre, double salariobase) {
        this.nombre = nombre;
        this.salariobase = salariobase;
    }

    public String getNombre() {
        return nombre;
    }

    public abstract double calcularSalariobruto();
}
