public class Principal {
    public static void main(String[] args) {
        EmpleadoHora emp = new EmpleadoHora("Juan", 20000, 10);
        System.out.println("Salario: " + emp.calcularSalariobruto());
    }
}
